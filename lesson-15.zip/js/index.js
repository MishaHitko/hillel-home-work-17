import {categories} from "./data.js";
import {categoriesGoods} from "./creatElem.js";


categoriesGoods(categories);